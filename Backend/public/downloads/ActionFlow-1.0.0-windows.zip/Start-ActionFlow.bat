@echo off
title ActionFlow Desktop
cd /d "%~dp0"
echo Launching ActionFlow Desktop App...
where electron >nul 2>nul
if %errorlevel% neq 0 (
    npx electron .
) else (
    electron .
)
