========================================================================
             ActionFlow Desktop Client for Windows
========================================================================

How to Run:
1. Double click "Start-ActionFlow.bat" to launch ActionFlow in desktop mode.
2. Or double click "ActionFlow-Silent.vbs" to launch without a command window.

Features:
- Native Windows desktop window & system tray icon
- Native OS notifications for incoming messages & AI task suggestions
- Automatic live connection to your ActionFlow workspace
